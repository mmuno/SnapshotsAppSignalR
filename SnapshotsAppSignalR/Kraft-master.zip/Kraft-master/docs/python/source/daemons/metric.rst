metric
********************

Metric daemon is a simple daemon that allows to

------


.. automodule:: cloud.daemons.metric.main
        :members:
        :private-members:
        :exclude-members: ipcmapping
