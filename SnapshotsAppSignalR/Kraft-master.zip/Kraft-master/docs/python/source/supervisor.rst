Supervisor
**************************

The supervisor is the heart of the project, preparing the daemons and then starting and monitoring them to ensure the best possible performance and stability.
