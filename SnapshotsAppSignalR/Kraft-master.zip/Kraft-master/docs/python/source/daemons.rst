Daemons
*************************************

The Kraft ecosystem uses daemons to distribute tasks and allow high performance.
Communication between the daemons is ensured using the ZeroMQ library.



.. toctree::
   :maxdepth: 2
   
   daemons/tcpexposer.rst
   daemons/metric.rst
